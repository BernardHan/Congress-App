package com.congress.han.congressapi;

import java.io.Serializable;

/**
 * Created by Han on 11/29/16.
 */

public class legislatorInfo implements Serializable{
    private String id;
    private String party;
    private String state;
    private String district;
    private String photoUrl;
    private String name;
    private String chamber;
    private String title;
    private String email;

    private String phone;
    private String term_start;
    private String term_end;
    private String fax;
    private String birthday;
    private String facebook;
    private String twitter;
    private String website;
    private String office;

    public legislatorInfo(String id, String party, String state, String district, String photoUrl,
                          String name, String chamber, String title, String email,
                          String phone, String term_start, String term_end, String fax, String birthday,
                          String facebook, String twitter, String website, String office){
        this.id = id;
        this.party = party;
        this.state = state;
        this.district =district;
        this.photoUrl = photoUrl;
        this.name = name;
        this.chamber = chamber;
        this.title = title;
        this.email = email;

        this.phone = phone;
        this.term_start = term_start;
        this.term_end = term_end;
        this.fax = fax;
        this.birthday = birthday;
        this.facebook = facebook;
        this.twitter = twitter;
        this.website = website;
        this.office = office;

    }
    public String getId(){return id;}
    public String getParty(){return party;}
    public String getState(){return state;}
    public String getDistrict(){return district;}
    public String getPhoto(){return photoUrl;}
    public String getName(){return name;}
    public String getChamber(){return chamber;}
    public String getTitle(){return title;}
    public String getEmail(){return email;}

    public String getPhone(){return phone;}
    public String getTerm_start(){return term_start;}
    public String getTerm_end(){return term_end;}
    public String getFax(){return fax;}
    public String getBirthday(){return birthday;}
    public String getFacebook(){return facebook;}
    public String getTwitter(){return twitter;}
    public String getWebsite(){return website;}
    public String getOffice(){return office;}
}
