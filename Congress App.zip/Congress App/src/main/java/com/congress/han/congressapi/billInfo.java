package com.congress.han.congressapi;

import java.io.Serializable;

/**
 * Created by Han on 11/30/16.
 */


public class billInfo implements Serializable {
    private String id;
    private String title;
    private String introduce_on;

    private String type;
    private String sponsor;
    private String chamber;
    private String status;
    private String congress;
    private String version;
    private String url;


    public billInfo(String id, String title, String introduce_on, String type, String sponsor,
                    String chamber, String status, String congress, String version, String url){
        this.id = id;
        this.title = title;
        this.introduce_on = introduce_on;

        this.type = type;
        this.sponsor = sponsor;
        this.chamber = chamber;
        this.status = status;
        this.congress = congress;
        this.version = version;
        this.url = url;
    }

    public String getId(){return id;}
    public String getTitle(){return title;}
    public String getIntroduce_on(){return introduce_on;}

    public String getType(){return type;}
    public String getSponsor(){return sponsor;}
    public String getChamber(){return chamber;}
    public String getStatus(){return status;}
    public String getCongress(){return congress;}
    public String getVersion(){return version;}
    public String getUrl(){return url;}
}
