package com.congress.han.congressapi;

/**
 * Created by Han on 11/28/16.
 */
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;

public class legislatorsenate extends Fragment{
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View v = inflater.inflate(R.layout.legislatorsenate, container, false);
        final String[] navIndex = new String[]{"A", "B", "C", "D", "E", "F", "G", "H", "I","J", "K", "L", "M", "N",
                "P", "R", "S", "T", "U", "V", "W"};
        AsyncJson task = new AsyncJson();
        task.execute("senate");
        try {
            final legislatorInfo[] legislatorsArray = task.get();
            final ListView listView = (ListView) v.findViewById(R.id.legislatorSenateList);
            legislatorArrayAdapter adapter = new legislatorArrayAdapter(listView.getContext(), R.layout.legislatorentry, legislatorsArray);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent viewDetail = new Intent(v.getContext(), detail_legislator.class);
                    legislatorInfo legislator = legislatorsArray[position];
                    viewDetail.putExtra("Info", legislator);
                    startActivity(viewDetail);
                }
            });

            // handle index navigation
            LinearLayout indexLayout = (LinearLayout) v.findViewById(R.id.senateIndex);
            for(int i = 0; i < navIndex.length; i++){
                final Button indBtn = new Button(getContext());
                indBtn.setText(navIndex[i]);
                indBtn.setTextSize(15);
                indBtn.setId(i);
                indBtn.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
                indBtn.setBackgroundColor(0x80FFFFFF);
                indexLayout.addView(indBtn);

                indBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //listView.setSelection(indBtn.getId());
                        for(int ind = 0; ind < legislatorsArray.length; ind++){
                            legislatorInfo legislator = legislatorsArray[ind];
                            if(navIndex[indBtn.getId()].charAt(0) == legislator.getName().charAt(0)){
                                listView.setSelection(ind);
                                break;
                            }
                        }
                    }
                });
            }
        }
        catch (Exception e){
            System.out.println("can get names!");
        }
        //Returning the layout file after inflating
        return v;
    }
}
