package com.congress.han.congressapi;

/**
 * Created by Han on 11/28/16.
 */
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class favPager extends FragmentStatePagerAdapter{
    //integer to count number of tabs
    int tabCount;

    //Constructor to the class
    public favPager(FragmentManager fm, int tabCount) {
        super(fm);
        //Initializing tab count
        this.tabCount= tabCount;
    }

    //Overriding method getItem
    @Override
    public Fragment getItem(int position) {
        //Returning the current tabs
        switch (position) {
            case 0:
                favLegislator legislator = new favLegislator();
                return legislator;
            case 1:
                favBill bill = new favBill();
                return bill;
            case 2:
                favCom com = new favCom();
                return com;
            default:
                return null;
        }
    }
    //Overriden method getCount to get the number of tabs
    @Override
    public int getCount() {
        return tabCount;
    }
}
