package com.congress.han.congressapi;

/**
 * Created by Han on 11/28/16.
 */
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class favLegislator extends Fragment{
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View v = inflater.inflate(R.layout.favlegislator, container, false);
        try {
            File dir = getContext().getFilesDir();
            File[] fileList = dir.listFiles();


            List<legislatorInfo> temp = new ArrayList<legislatorInfo>();
            // get the object from storage file
            for(int i = 0; i < fileList.length; i++){
                String filename = fileList[i].getName();
                if(filename.contains("legislators_")) {
                    FileInputStream fi = getContext().openFileInput(filename);
                    ObjectInputStream objectStream = new ObjectInputStream(fi);
                    temp.add((legislatorInfo) objectStream.readObject());
                    objectStream.close();
                    fi.close();
                }
            }

            legislatorInfo[] tempArray = temp.toArray(new legislatorInfo[0]);

            Arrays.sort(tempArray,new NameComparator());
            final legislatorInfo[] legislatorsArray = tempArray;
            //final legislatorInfo[] legislatorsArray = new legislatorInfo[]{single};
            final ListView listView = (ListView) v.findViewById(R.id.favLegislatorList);
            legislatorArrayAdapter adapter = new legislatorArrayAdapter(listView.getContext(), R.layout.legislatorentry, legislatorsArray);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    // value = (String) listView.getItemAtPosition(position);
                    //String name = legislatorsArray[position].getName();
                    //Toast.makeText(getContext(), name, Toast.LENGTH_LONG).show();
                    Intent viewDetail = new Intent(v.getContext(), detail_legislator.class);
                    legislatorInfo legislator = legislatorsArray[position];
                    viewDetail.putExtra("Info", legislator);
                    startActivity(viewDetail);
                }
            });

            // create navi index
            Set<String> index = new HashSet<String>();
            for(int i = 0; i < legislatorsArray.length; i++){
                index.add(String.valueOf(legislatorsArray[i].getName().charAt(0)));
            }
            final String[] navIndex = index.toArray(new String[0]);
            // handle index navigation
            LinearLayout indexLayout = (LinearLayout) v.findViewById(R.id.favIndex);
            for(int i = 0; i < navIndex.length; i++){
                final Button indBtn = new Button(getContext());
                indBtn.setText(navIndex[i]);
                indBtn.setTextSize(15);
                indBtn.setId(i);
                indBtn.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
                indBtn.setBackgroundColor(0x80FFFFFF);
                indexLayout.addView(indBtn);

                indBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //listView.setSelection(indBtn.getId());
                        for(int ind = 0; ind < legislatorsArray.length; ind++){
                            legislatorInfo legislator = legislatorsArray[ind];
                            if(navIndex[indBtn.getId()].charAt(0) == legislator.getName().charAt(0)){
                                listView.setSelection(ind);
                                break;
                            }
                        }
                    }
                });
            }
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
        //Returning the layout file after inflating
        return v;
    }
}
