package com.congress.han.congressapi;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Han on 11/29/16.
 */

public class legislatorArrayAdapter extends ArrayAdapter<legislatorInfo> {
    private Context context;
    private legislatorInfo[] legislators;

    public legislatorArrayAdapter(Context context, int theLayout, legislatorInfo[] legislators){
        super(context, theLayout, legislators);

        this.context = context;
        this.legislators = legislators;
    }

    // called when building the list
    public View getView(int position, View theView, ViewGroup parent) {
        legislatorInfo info = legislators[position];

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.legislatorentry, null);

        ImageView photo = (ImageView) view.findViewById(R.id.legislatorPhoto);
        TextView name = (TextView) view.findViewById(R.id.legislatorName);
        TextView party = (TextView) view.findViewById(R.id.legislatorParty);

        String legislatorName = info.getName();
        name.setText(legislatorName);

        String legislatorParty = "(" + info.getParty() + ")" + info.getState() + " - ";
        String district = info.getDistrict() == "null" ? "N.A" : "District " + info.getDistrict();
        legislatorParty += district;
        party.setText(legislatorParty);

        String photoUrl = info.getPhoto();
        new imageLoader(photoUrl, photo).execute(); // photo will be loaded, and set to the view in the post execution

        return view;
    }


}
