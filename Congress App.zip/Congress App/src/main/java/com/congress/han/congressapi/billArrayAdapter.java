package com.congress.han.congressapi;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Han on 11/29/16.
 */

public class billArrayAdapter extends ArrayAdapter<billInfo> {
    private Context context;
    private billInfo[] bills;

    public billArrayAdapter(Context context, int theLayout, billInfo[] bills){
        super(context, theLayout, bills);

        this.context = context;
        this.bills = bills;
    }

    // called when building the list
    public View getView(int position, View theView, ViewGroup parent) {
        billInfo info = bills[position];

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.billentry, null);

        TextView id = (TextView) view.findViewById(R.id.billID);
        TextView title = (TextView) view.findViewById(R.id.billTitle);
        TextView date = (TextView) view.findViewById(R.id.billIntroduceOn);

        String billID = info.getId();
        id.setText(billID);

        String billTitle = info.getTitle();
        title.setText(billTitle);

        String billDate = info.getIntroduce_on();
        date.setText(billDate);

        return view;
    }


}
