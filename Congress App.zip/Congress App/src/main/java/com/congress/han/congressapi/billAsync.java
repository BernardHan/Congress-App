package com.congress.han.congressapi;

/**
 * Created by Han on 11/27/16.
 */

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class billAsync extends AsyncTask<String, Void, billInfo[]> {

    protected billInfo[] doInBackground(String... args) {
        String request;
        String type = args[0];
        if(type.equals("new")){
            // request new bills
            request = "http://sample-env.vjpnd4wkak.us-west-2.elasticbeanstalk.com/index.php?congress=bills&bills_active=false";
        }
        else{
            // request active bills
            request = "http://sample-env.vjpnd4wkak.us-west-2.elasticbeanstalk.com/index.php?congress=bills&bills_active=true";
        }
        try{
            URL url = new URL(request);
            InputStream is = url.openStream();
            BufferedReader rd =	new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            int ch;
            while((ch = rd.read()) != -1){
                sb.append((char) ch);
            }
            String text = sb.toString();
            JSONObject json = new JSONObject(text);
            //System.out.println(json.getString("results"));
            JSONArray bills = json.getJSONArray("results"); // all the legislator information here
            billInfo[] billsArray;
            billsArray = getBills(bills);
            Arrays.sort(billsArray, new DateComparator());

            return billsArray;
        }
        catch(MalformedURLException e){
            System.out.println("url not good!");
        }
        catch(IOException e){
            System.out.println("IO error!");
        }
        catch(JSONException e){
            System.out.println("Json wrong!!");
        }
        return null;
    }

    private billInfo[] getBills(JSONArray bills){
        try {

            int length = bills.length();
            billInfo[] billsArray = new billInfo[length];

            for (int i = 0; i < length; i++) {
                JSONObject bill = bills.getJSONObject(i);

                String id = bill.getString("bill_id").toUpperCase();
                String official_title = bill.getString("official_title");
                String introduced_on = bill.getString("introduced_on");

                String type = bill.getString("bill_type").toUpperCase();
                String sponsor = bill.getJSONObject("sponsor").getString("title") + ". " +
                                    bill.getJSONObject("sponsor").getString("last_name") + ", " +
                                    bill.getJSONObject("sponsor").getString("first_name");
                String chamber = bill.getString("chamber");
                String status = bill.getJSONObject("history").getBoolean("active") == true ? "Active" : "Inactive";
                String congress = bill.getJSONObject("urls").getString("congress");
                String version = bill.getJSONObject("last_version").getString("version_name");
                String url = bill.getJSONObject("last_version").getJSONObject("urls").getString("pdf");

                //System.out.println(name + ": " + id + ", " + party + ", " + state + ", " + district);
                billsArray[i] = new billInfo(id, official_title,introduced_on, type, sponsor,
                                                chamber, status, congress, version, url);
            }
            return billsArray;
        }
        catch (JSONException e){
            System.out.println("Legislators by state error.");
        }
        return null;
    }
}


class DateComparator implements Comparator<billInfo>{
    @Override
    public int compare(billInfo bill1,billInfo bill2){
        return -1 * bill1.getIntroduce_on().compareTo(bill2.getIntroduce_on());
    }
}