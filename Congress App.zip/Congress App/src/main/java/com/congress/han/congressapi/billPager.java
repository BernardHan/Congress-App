package com.congress.han.congressapi;

/**
 * Created by Han on 11/28/16.
 */
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class billPager extends FragmentStatePagerAdapter{
    //integer to count number of tabs
    int tabCount;

    //Constructor to the class
    public billPager(FragmentManager fm, int tabCount) {
        super(fm);
        //Initializing tab count
        this.tabCount= tabCount;
    }

    //Overriding method getItem
    @Override
    public Fragment getItem(int position) {
        //Returning the current tabs
        switch (position) {
            case 0:
                billActive activeBill = new billActive();
                return activeBill;
            case 1:
                billNew newBill = new billNew();
                return newBill;
            default:
                return null;
        }
    }
    //Overriden method getCount to get the number of tabs
    @Override
    public int getCount() {
        return tabCount;
    }
}
