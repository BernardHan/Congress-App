package com.congress.han.congressapi;

/**
 * Created by Han on 11/27/16.
 */

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class AsyncJson extends AsyncTask<String, Void, legislatorInfo[]> {

    protected legislatorInfo[] doInBackground(String... args) {
        String request = "http://sample-env.vjpnd4wkak.us-west-2.elasticbeanstalk.com/index.php?congress=legislators&chamber=state";
        String chamber = args[0];
        try{
            URL url = new URL(request);
            //URLConnection connection = url.openConnection();
            //connection.connect();
            //InputStream is = connection.getInputStream();
            InputStream is = url.openStream();
            BufferedReader rd =	new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            int ch;
            while((ch = rd.read()) != -1){
                sb.append((char) ch);
            }
            String text = sb.toString();
            JSONObject json = new JSONObject(text);
            //System.out.println(json.getString("results"));
            JSONArray legislators = json.getJSONArray("results"); // all the legislator information here
            legislatorInfo[] legislatorsArray = new legislatorInfo[legislators.length()];
            legislatorsArray = getLegislators(legislators);
            if(chamber.equals("state")) {

                Arrays.sort(legislatorsArray,new StateComparator());
            }
            else if(chamber.equals("house")){
                // take all the house
                legislatorsArray = legislatorsByHouse(legislatorsArray);
                Arrays.sort(legislatorsArray,new NameComparator());
            }
            else if(chamber.equals("senate")) {
                legislatorsArray = legislatorsBySenate(legislatorsArray);
                Arrays.sort(legislatorsArray,new NameComparator());
            }
            return legislatorsArray;
        }
        catch(MalformedURLException e){
            System.out.println("url not good!");
        }
        catch(IOException e){
            System.out.println("IO error!");
        }
        catch(JSONException e){
            System.out.println("Json wrong!!");
        }
        return null;
    }

    private legislatorInfo[] getLegislators(JSONArray legislators){
        try {

            int length = legislators.length();
            legislatorInfo[] legislatorsArray = new legislatorInfo[length];
            String photoUrlBase = "https://theunitedstates.io/images/congress/225x275/";
            for (int i = 0; i < length; i++) {
                JSONObject legislator = legislators.getJSONObject(i);
                String id = legislator.getString("bioguide_id");
                String party = legislator.getString("party");
                String state = legislator.getString("state_name");
                String district = legislator.getString("district");
                String chamber = legislator.getString("chamber");
                String photoUrl = photoUrlBase + id + ".jpg";
                String name = legislator.getString("last_name") + ", " + legislator.getString("first_name");

                String title = legislator.getString("title");
                String email = legislator.getString("oc_email");

                String phone = legislator.getString("phone");
                String term_start = legislator.getString("term_start");
                String term_end = legislator.getString("term_end");

                String fax;
                String birthday;
                String facebook;
                String twitter;
                String website;
                String office;

                try{
                    fax = legislator.getString("fax");
                }
                catch (JSONException e){
                    fax = "null";
                }
                try{
                    birthday = legislator.getString("birthday");
                }
                catch (JSONException e){
                    birthday = "null";
                }
                try{
                    facebook = legislator.getString("facebook_id");
                }
                catch (JSONException e){
                    facebook = "null";
                }
                try{
                    twitter = legislator.getString("twitter_id");
                }
                catch (JSONException e){
                    twitter = "null";
                }
                try{
                    website = legislator.getString("website");
                }
                catch (JSONException e){
                    website = "null";
                }
                try{
                    office = legislator.getString("office");
                }
                catch (JSONException e){
                    office = "null";
                }

                //System.out.println(name + ": " + id + ", " + party + ", " + state + ", " + district);
                legislatorsArray[i] = new legislatorInfo(id, party, state, district, photoUrl, name, chamber,
                                                            title, email, phone, term_start, term_end, fax,
                                                            birthday, facebook, twitter, website, office);
            }
            return legislatorsArray;
        }
        catch (JSONException e){
            System.out.println("Legislators by state error.");
        }
        return null;
    }

    private legislatorInfo[] legislatorsByHouse(legislatorInfo[] legislatorInfos){
        List<legislatorInfo> temp = new ArrayList<legislatorInfo>();
        for(int i = 0; i < legislatorInfos.length; i++){
            if(legislatorInfos[i].getChamber().equals("house")){
                // add into thelist
                temp.add(legislatorInfos[i]);
            }
        }
        legislatorInfo[] result = temp.toArray(new legislatorInfo[0]);
        return result;
    }

    private legislatorInfo[] legislatorsBySenate(legislatorInfo[] legislatorInfos){
        List<legislatorInfo> temp = new ArrayList<legislatorInfo>();
        for(int i = 0; i < legislatorInfos.length; i++){
            if(legislatorInfos[i].getChamber().equals("senate")){
                // add into thelist
                temp.add(legislatorInfos[i]);
            }
        }
        legislatorInfo[] result = temp.toArray(new legislatorInfo[0]);
        return result;
    }
}


class StateComparator implements Comparator<legislatorInfo>{
    @Override
    public int compare(legislatorInfo legislator1,legislatorInfo legislator2){
        return legislator1.getState().compareTo(legislator2.getState());
    }
}

class NameComparator implements Comparator<legislatorInfo>{
    @Override
    public int compare(legislatorInfo legislator1,legislatorInfo legislator2){
        return legislator1.getName().compareTo(legislator2.getName());
    }
}