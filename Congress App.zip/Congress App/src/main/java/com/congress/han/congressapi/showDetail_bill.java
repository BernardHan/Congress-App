package com.congress.han.congressapi;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 * Created by Han on 11/30/16.
 */

public class showDetail_bill extends Fragment{
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.billdetail, container, false);
        final billInfo bill = (billInfo) getArguments().getSerializable("Info");
        //TextView name = (TextView) v.findViewById(R.id.billDetailId);
        //name.setText(bill.getId());

        TextView idText = (TextView) v.findViewById(R.id.billDetailId);
        TextView titleText = (TextView) v.findViewById(R.id.billDetailTitle);
        TextView typeText = (TextView) v.findViewById(R.id.billDetailType);
        TextView sponsorText = (TextView) v.findViewById(R.id.billDetailSponsor);
        TextView chamberText = (TextView) v.findViewById(R.id.billDetailChamber);
        TextView statusText = (TextView) v.findViewById(R.id.billDetailStatus);
        TextView introduceText = (TextView) v.findViewById(R.id.billDetailIntroduce);
        TextView congressText = (TextView) v.findViewById(R.id.billDetailCongress);
        TextView versionText = (TextView) v.findViewById(R.id.billDetailVersion);
        TextView urlText = (TextView) v.findViewById(R.id.billDetailUrl);

        String id = bill.getId();
        String title = bill.getTitle();
        String type = bill.getType();
        String sponsor = bill.getSponsor();
        String chamber = bill.getChamber();
        String status = bill.getStatus();
        String introduce = bill.getIntroduce_on();
        String congress = bill.getCongress();
        String version = bill.getVersion();
        String url = bill.getUrl();

        idText.setText(id);
        titleText.setText(title);
        typeText.setText(type);
        sponsorText.setText(sponsor);
        chamberText.setText(chamber);
        statusText.setText(status);
        introduceText.setText(introduce);
        congressText.setText(congress);
        versionText.setText(version);
        urlText.setText(url);

        // handle the favorites
        final File dir = getContext().getFilesDir();
        final String filename = "bills_" + bill.getId();
        CheckBox favButton = (CheckBox) v.findViewById(R.id.billDetailFav);
        File[] fileList = dir.listFiles();
        for(int i = 0; i < fileList.length; i++) {
            String nameInList = fileList[i].getName();
            if(nameInList.equals(filename)){
                // star should be star, liked
                favButton.setChecked(true);
                break;
            }
        }

        favButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    try {
                        FileOutputStream fo = getContext().openFileOutput(filename, Context.MODE_PRIVATE);
                        ObjectOutputStream objectStream = new ObjectOutputStream(fo);
                        objectStream.writeObject(bill);
                        objectStream.close();
                        fo.close();
                    } catch (IOException e) {
                        Toast.makeText(getContext(), "Sorry, cannot store this item", Toast.LENGTH_LONG).show();
                    }
                }
                else{
                    // delete the file

                    File file = new File(dir, filename);
                    file.delete();
                }
            }
        });

        return v;
    }
}
