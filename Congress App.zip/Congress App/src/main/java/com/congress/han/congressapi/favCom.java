package com.congress.han.congressapi;

/**
 * Created by Han on 11/28/16.
 */
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class favCom extends Fragment{
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View v = inflater.inflate(R.layout.favcom, container, false);
        try {
            File dir = getContext().getFilesDir();
            File[] fileList = dir.listFiles();


            List<comInfo> temp = new ArrayList<comInfo>();
            // get the object from storage file
            for(int i = 0; i < fileList.length; i++){
                String filename = fileList[i].getName();
                if(filename.contains("coms_")) {
                    FileInputStream fi = getContext().openFileInput(filename);
                    ObjectInputStream objectStream = new ObjectInputStream(fi);
                    temp.add((comInfo) objectStream.readObject());
                    objectStream.close();
                    fi.close();
                }
            }

            final comInfo[] comsArray = temp.toArray(new comInfo[0]);
            Arrays.sort(comsArray,new comNameComparator());

            final ListView listView = (ListView) v.findViewById(R.id.favComList);
            comArrayAdapter adapter = new comArrayAdapter(listView.getContext(), R.layout.comentry, comsArray);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent viewDetail = new Intent(v.getContext(), detail_com.class);
                    comInfo com = comsArray[position];
                    viewDetail.putExtra("Info", com);
                    startActivity(viewDetail);
                }
            });
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
        //Returning the layout file after inflating
        return v;
    }
}
