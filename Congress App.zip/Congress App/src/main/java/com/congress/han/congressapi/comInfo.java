package com.congress.han.congressapi;

import java.io.Serializable;

/**
 * Created by Han on 11/30/16.
 */


public class comInfo implements Serializable {
    private String id;
    private String name;
    private String chamber;

    private String parent;
    private String phone;
    private String office;


    public comInfo(String id, String name, String chamber, String parent, String phone, String office){
        this.id = id;
        this.name = name;
        this.chamber = chamber;
        this.parent = parent;
        this.phone = phone;
        this.office = office;
    }

    public String getId(){return id;}
    public String getName(){return name;}
    public String getChamber(){return chamber;}
    public String getParent(){return parent;}
    public String getPhone(){return phone;}
    public String getOffice(){return office;}
    //public String getChamber(){return chamber;}
}
