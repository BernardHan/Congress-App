package com.congress.han.congressapi;

/**
 * Created by Han on 11/27/16.
 */

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class comAsync extends AsyncTask<String, Void, comInfo[]> {

    protected comInfo[] doInBackground(String... args) {
        String request = "http://sample-env.vjpnd4wkak.us-west-2.elasticbeanstalk.com/index.php?congress=committees";
        String type = args[0]; // house, senate, joint

        try{
            URL url = new URL(request);
            InputStream is = url.openStream();
            BufferedReader rd =	new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            int ch;
            while((ch = rd.read()) != -1){
                sb.append((char) ch);
            }
            String text = sb.toString();
            JSONObject json = new JSONObject(text);
            //System.out.println(json.getString("results"));
            JSONArray coms = json.getJSONArray("results"); // all the legislator information here
            comInfo[] comsArray = getComs(coms);
            comsArray = comFilter(comsArray, type);

            Arrays.sort(comsArray, new comNameComparator());

            return comsArray;
        }
        catch(MalformedURLException e){
            System.out.println("url not good!");
        }
        catch(IOException e){
            System.out.println("IO error!");
        }
        catch(JSONException e){
            System.out.println("Json wrong!!");
        }
        return null;
    }

    private comInfo[] comFilter(comInfo[] comInfos, String type){
        List<comInfo> temp = new ArrayList<comInfo>();
        for(int i = 0; i < comInfos.length; i++){
            if(comInfos[i].getChamber().equals(type)){
                // add into thelist
                temp.add(comInfos[i]);
            }
        }
        comInfo[] result = temp.toArray(new comInfo[0]);
        return result;
    }

    private comInfo[] getComs(JSONArray coms){
        try {

            int length = coms.length();
            comInfo[] comsArray = new comInfo[length];

            for (int i = 0; i < length; i++) {
                JSONObject com = coms.getJSONObject(i);
                String id = com.getString("committee_id");
                String name = com.getString("name");
                String chamber = com.getString("chamber");

                String parent;
                try{
                    parent = com.getString("parent_committee_id");
                }
                catch (JSONException e){
                    parent = "N.A";
                }
                String phone;
                try {
                    phone = com.getString("phone");
                }
                catch(JSONException e){
                    phone = "N.A";
                }
                String office;
                try{
                    office = com.getString("office");
                }
                catch (JSONException e){
                    office = "N.A";
                }

                comsArray[i] = new comInfo(id, name, chamber, parent, phone, office);

            }
            return comsArray;
        }
        catch (JSONException e){
            System.out.println("Legislators by state error.");
        }
        return null;
    }
}


class comNameComparator implements Comparator<comInfo>{
    @Override
    public int compare(comInfo com1, comInfo com2){
        return com1.getName().compareTo(com2.getName());
    }
}