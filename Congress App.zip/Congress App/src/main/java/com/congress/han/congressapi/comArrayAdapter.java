package com.congress.han.congressapi;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

/**
 * Created by Han on 11/29/16.
 */

public class comArrayAdapter extends ArrayAdapter<comInfo> {
    private Context context;
    private comInfo[] coms;

    public comArrayAdapter(Context context, int theLayout, comInfo[] coms){
        super(context, theLayout, coms);

        this.context = context;
        this.coms = coms;
    }

    // called when building the list
    public View getView(int position, View theView, ViewGroup parent) {
        comInfo info = coms[position];

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.comentry, null);

        TextView id = (TextView) view.findViewById(R.id.comID);
        TextView name = (TextView) view.findViewById(R.id.comName);
        TextView chamber = (TextView) view.findViewById(R.id.comChamber);

        String comID = info.getId();
        id.setText(comID);

        String comName = info.getName();
        name.setText(comName);

        String comChamber = info.getChamber();
        chamber.setText(comChamber);

        return view;
    }


}
