package com.congress.han.congressapi;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Calendar;

/**
 * Created by Han on 11/30/16.
 */

public class showDetail_legislator extends Fragment{
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.legislatordetail, container, false);
        final legislatorInfo legislator = (legislatorInfo) getArguments().getSerializable("Info");

        ImageView photo = (ImageView) v.findViewById(R.id.photo);
        ImageView partyImage = (ImageView) v.findViewById(R.id.partyImage);
        TextView partyText = (TextView) v.findViewById(R.id.party);
        TextView nameText = (TextView) v.findViewById(R.id.legislatorDetailName);
        TextView emailText = (TextView) v.findViewById(R.id.legislatorDetailEmail);
        TextView chamberText = (TextView) v.findViewById(R.id.legislatorDetailChamber);
        TextView phoneText = (TextView) v.findViewById(R.id.legislatorDetailPhone);
        TextView startText = (TextView) v.findViewById(R.id.legislatorDetailStart);
        TextView endText = (TextView) v.findViewById(R.id.legislatorDetailEnd);
        TextView officeText = (TextView) v.findViewById(R.id.legislatorDetailOffice);
        TextView stateText = (TextView) v.findViewById(R.id.legislatorDetailState);
        TextView faxText = (TextView) v.findViewById(R.id.legislatorDetailFax);
        TextView birthdayText = (TextView) v.findViewById(R.id.legislatorDetailBirthday);
        ProgressBar bar = (ProgressBar) v.findViewById(R.id.progression);
        TextView barText = (TextView) v.findViewById(R.id.progressionText);

        // get other stuff
        String party = legislator.getParty() == "R" ? "Republican" : "Democrat";
        String name = legislator.getTitle() + ". " + legislator.getName();
        String email = legislator.getEmail() == "null" ? "N.A" : legislator.getEmail();
        String chamber = legislator.getChamber();
        String phone = legislator.getPhone() == "null" ? "N.A" : legislator.getPhone();
        String term_start = legislator.getTerm_start();
        String term_end = legislator.getTerm_end();
        String office = legislator.getOffice() == "null" ? "N.A" : legislator.getOffice();
        String state = legislator.getState();
        String fax = legislator.getFax() == "null" ? "N.A" : legislator.getFax();
        String birthday = legislator.getBirthday() == "null" ? "N.A" : legislator.getBirthday();
        String photoUrl = legislator.getPhoto();
        final String facebook = legislator.getFacebook();
        final String twitter = legislator.getTwitter();
        final String website = legislator.getWebsite();

        // calculate the term
        int term = calculateTerm(term_start, term_end);

        // set content view here
        new imageLoader(photoUrl, photo).execute();
        partyText.setText(party);
        nameText.setText(name);
        emailText.setText(email);
        chamberText.setText(chamber);
        phoneText.setText(phone);
        startText.setText(term_start);
        endText.setText(term_end);
        officeText.setText(office);
        stateText.setText(state);
        faxText.setText(fax);
        birthdayText.setText(birthday);
        if(party == "Republican"){
            partyImage.setImageResource(R.drawable.r);
        }
        else {
            partyImage.setImageResource(R.drawable.d);
        }

        bar.setProgress(term);
        barText.setText(term + "%");

        // handle the web service
        final ImageButton facebookButton = (ImageButton) v.findViewById(R.id.facebook);
        ImageButton twitterButton = (ImageButton) v.findViewById(R.id.twitter);
        ImageButton websiteButton = (ImageButton) v.findViewById(R.id.website);

        facebookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!facebook.equals("null")) {
                    String link = "https://www.facebook.com/" + facebook;
                    Uri uri = Uri.parse(link);
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                }
                else{
                    // make a toast
                    Toast.makeText(getContext(), "Sorry, Facebook is unavailable", Toast.LENGTH_LONG).show();
                }
            }
        });

        twitterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!twitter.equals("null")) {
                    String link = "https://twitter.com/" + twitter;
                    Uri uri = Uri.parse(link);
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                }
                else{
                    // make a toast
                    Toast.makeText(getContext(), "Sorry, Twitter is unavailable", Toast.LENGTH_LONG).show();
                }
            }
        });

        websiteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!website.equals("null")) {
                    Uri uri = Uri.parse(website);
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                }
                else{
                    // make a toast
                    Toast.makeText(getContext(), "Sorry, Website is unavailable", Toast.LENGTH_LONG).show();
                }
            }
        });

        // handle the favorites
        final File dir = getContext().getFilesDir();
        final String filename = "legislators_" + legislator.getId();
        CheckBox favButton = (CheckBox) v.findViewById(R.id.legislatorDetailFav);
        File[] fileList = dir.listFiles();
        for(int i = 0; i < fileList.length; i++) {
            String nameInList = fileList[i].getName();
            if(nameInList.equals(filename)){
                // star should be star, liked
                favButton.setChecked(true);
                break;
            }
        }

        favButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    try {
                        FileOutputStream fo = getContext().openFileOutput(filename, Context.MODE_PRIVATE);
                        ObjectOutputStream objectStream = new ObjectOutputStream(fo);
                        objectStream.writeObject(legislator);
                        objectStream.close();
                        fo.close();
                    } catch (IOException e) {
                        Toast.makeText(getContext(), "Sorry, cannot store this item", Toast.LENGTH_LONG).show();
                    }
                }
                else{
                    // delete the file

                    File file = new File(dir, filename);
                    file.delete();
                }
            }
        });

        return v;
    }

    private int calculateTerm(String start, String end){
        int startY, endY, currentY, startM, endM, currentM, startD, endD, currentD, startDays, endDays, currentDays;
        String[] parts = start.split("-");
        startY = Integer.parseInt(parts[0]);
        startM = Integer.parseInt(parts[1]);
        startD = Integer.parseInt(parts[2]);

        parts = end.split("-");
        endY = Integer.parseInt(parts[0]);
        endM = Integer.parseInt(parts[1]);
        endD = Integer.parseInt(parts[2]);

        Calendar calendar = Calendar.getInstance();
        currentY = calendar.get(Calendar.YEAR);
        currentM = calendar.get(Calendar.MONTH) + 1;
        currentD = calendar.get(Calendar.DAY_OF_MONTH);

        startDays = startY * 365 + startM * 31 + startD;
        endDays = endY * 365 + endM * 31 + endD;
        currentDays = currentY * 365 + currentM * 31 + currentD;


        return Math.round((float)(currentDays - startDays)/(endDays - startDays) * 100);
    }
}
