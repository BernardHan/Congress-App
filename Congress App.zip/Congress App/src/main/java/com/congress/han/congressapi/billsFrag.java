package com.congress.han.congressapi;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by Han on 11/28/16.
 */

public class billsFrag extends Fragment implements TabLayout.OnTabSelectedListener{
    //This is our tablayout
    private TabLayout tabLayout;

    //This is our viewPager
    private ViewPager viewPager;
    private View v;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //Initializing the tablayout
        v = inflater.inflate(R.layout.bills, container, false);
        tabLayout = (TabLayout) v.findViewById(R.id.tabLayoutBill);

        //Adding the tabs using addTab() method
        TabLayout.Tab activeBill = tabLayout.newTab();
        activeBill.setText("Active Bills");

        TabLayout.Tab newBill = tabLayout.newTab();
        newBill.setText("New Bills");

        tabLayout.addTab(activeBill);
        tabLayout.addTab(newBill);

        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        viewPager = (ViewPager) v.findViewById(R.id.pagerBill);
        //Creating our pager adapter
        billPager adapter = new billPager(getFragmentManager(), tabLayout.getTabCount());

        //Adding adapter to pager
        viewPager.setAdapter(adapter);

        //Adding onTabSelectedListener to swipe views
        tabLayout.setOnTabSelectedListener(this);
        return v;
    }


    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        viewPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }
}
