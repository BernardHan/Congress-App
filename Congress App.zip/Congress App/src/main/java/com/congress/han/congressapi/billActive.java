package com.congress.han.congressapi;

/**
 * Created by Han on 11/28/16.
 */
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

public class billActive extends Fragment{
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        final View v = inflater.inflate(R.layout.billactive, container, false);
        billAsync task = new billAsync();
        task.execute("active");
        try {
            final billInfo[] billsArray = task.get();
            final ListView listView = (ListView) v.findViewById(R.id.billActiveList);
            billArrayAdapter adapter = new billArrayAdapter(listView.getContext(), R.layout.billentry, billsArray);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent viewDetail = new Intent(v.getContext(), detail_bill.class);
                    billInfo bill = billsArray[position];
                    viewDetail.putExtra("Info", bill);
                    startActivity(viewDetail);
                }
            });
        }
        catch (Exception e){
            System.out.println("can get names!");
        }
        //Returning the layout file after inflating
        return v;
    }
}
