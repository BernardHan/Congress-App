package com.congress.han.congressapi;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 * Created by Han on 11/30/16.
 */

public class showDetail_com extends Fragment{
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.comdetail, container, false);
        final comInfo com = (comInfo) getArguments().getSerializable("Info");

        String empty = "        ";

        TextView idText = (TextView) v.findViewById(R.id.comDetailId);
        TextView nameText = (TextView) v.findViewById(R.id.comDetailName);
        ImageView chamberImage = (ImageView) v.findViewById(R.id.comChamberImage);
        TextView chamberText = (TextView) v.findViewById(R.id.comDetailChamber);
        TextView parentText = (TextView) v.findViewById(R.id.comDetailParent);
        TextView phoneText = (TextView) v.findViewById(R.id.comDetailPhone);
        TextView officeText = (TextView) v.findViewById(R.id.comDetailOffice);

        String id = com.getId();
        String name = com.getName();
        String chamber = com.getChamber();

        String parent = com.getParent();
        String phone = com.getPhone();
        String office = com.getOffice();

        idText.setText(id);
        nameText.setText(name);

        parentText.setText(parent);
        phoneText.setText(phone);
        officeText.setText(office);
        chamber = chamber.substring(0, 1).toUpperCase() + chamber.substring(1);
        if(chamber.equals("House")){
            chamberImage.setImageResource(R.drawable.h);
            chamber = empty + chamber;
        }
        chamberText.setText(chamber);



        // handle the favorites
        final File dir = getContext().getFilesDir();
        final String filename = "coms_" + com.getId();
        CheckBox favButton = (CheckBox) v.findViewById(R.id.comDetailFav);
        File[] fileList = dir.listFiles();
        for(int i = 0; i < fileList.length; i++) {
            String nameInList = fileList[i].getName();
            if(nameInList.equals(filename)){
                // star should be star, liked
                favButton.setChecked(true);
                break;
            }
        }

        favButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    try {
                        FileOutputStream fo = getContext().openFileOutput(filename, Context.MODE_PRIVATE);
                        ObjectOutputStream objectStream = new ObjectOutputStream(fo);
                        objectStream.writeObject(com);
                        objectStream.close();
                        fo.close();
                    } catch (IOException e) {
                        Toast.makeText(getContext(), "Sorry, cannot store this item", Toast.LENGTH_LONG).show();
                    }
                }
                else{
                    // delete the file
                    File file = new File(dir, filename);
                    file.delete();
                }
            }
        });
        return v;
    }
}
