package com.congress.han.congressapi;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Han on 11/29/16.
 */

public class imageLoader extends AsyncTask<Void, Void, Bitmap> {
    private String link;
    private ImageView photo;

    public imageLoader(String link, ImageView photo){
        this.link = link;
        this.photo = photo;
    }

    @Override
    protected Bitmap doInBackground(Void... args){
        try{
            URL src = new URL(link);
            HttpURLConnection connection = (HttpURLConnection) src.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream inputStream = connection.getInputStream();
            Bitmap imageMap = BitmapFactory.decodeStream(inputStream);
            return imageMap;
        }
        catch(MalformedURLException e){
            System.out.println("can not set url");
            //Log.e("Exception", e.getMessage());
            return null;
        }
        catch(IOException e){
            System.out.println("cannot set connect, or get stream");
            return null;
        }
    }

    @Override
    protected void onPostExecute(Bitmap image){
        super.onPostExecute(image);
        photo.setImageBitmap(image);
    }
}
